# VIA VA website

Marketing site for VIA VA — a virtual assistant agency ("Your team, virtually").

## Pages

- `viava-home.html` — home page (hero, why VIA VA, cost comparison, industries, FAQ teaser)
- `viava-how-it-works.html` — the matching/onboarding process in detail
- `viava-services-pricing.html` — full service categories + pricing tiers
- `viava-about.html` — mission, values, join the team, FAQ, contact form
- `viava-styles.css` — shared stylesheet for all four pages

Static HTML/CSS, no build step. Deploy by uploading these files to a web host's document root, with `viava-home.html` renamed to `index.html` so it loads as the site root.
